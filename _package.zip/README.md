# Chatbox Flashcards with Spaced Repetition

- AI Bot to help study with spaced reptitions of Data Structures and Algorithmic concepts
